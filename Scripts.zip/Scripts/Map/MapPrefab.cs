using UnityEngine;

[System.Serializable]
public class MapPrefab
{
    public MapPrefabType mapPrefabType;
    public GameObject mapPrefab;
}
