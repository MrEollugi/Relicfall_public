public interface IMoveState
{
    void Enter();
    void Update(InputData input);
    void Exit();
}
