using UnityEngine;

public class SoundEvent
{
    public Vector3 source;
    public float radius;
    public float priority;
}
