using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DashEffect : ISkillEffect
{
    public void Apply(ICombatEntity caster, ICombatEntity unused, SkillExecutionContext context)
    {

    }
}
