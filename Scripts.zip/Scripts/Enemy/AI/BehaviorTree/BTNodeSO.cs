using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BTNodeSO : ScriptableObject
{
    public abstract BTNode Build();
}
