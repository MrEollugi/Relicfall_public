public interface IInteractable
{
    void OnInteract();
}
